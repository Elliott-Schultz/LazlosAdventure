$player1.addItem("Decimator Piece 2")

Dir.chdir("..")