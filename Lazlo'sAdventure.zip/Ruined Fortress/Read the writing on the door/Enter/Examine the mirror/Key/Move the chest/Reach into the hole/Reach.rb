$player1.addItem("Pure String of the Elves")

Dir.chdir("..")