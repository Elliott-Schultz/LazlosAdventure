$player1.addIntelligence(5)

Dir.chdir("..")